public class Main {
	public static void main(String args[]) {
		Agenda MinhaAgenda = new Agenda();
	}
}
